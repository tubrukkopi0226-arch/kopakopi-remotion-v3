import React from "react";
import { Composition } from "remotion";
import { FenomenaKopi } from "./Video";
import { FPS, totalFrames } from "./scenes";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="FenomenaKopi"
      component={FenomenaKopi}
      durationInFrames={totalFrames()}
      fps={FPS}
      width={1080}
      height={1920}
      defaultProps={{ voUrl: null as string | null }}
    />
  );
};
