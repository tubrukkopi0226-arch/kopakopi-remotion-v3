// Naskah per slide. Setiap "beat" adalah teks yang tampil di layar selama `seconds` detik.
// Sesuaikan `seconds` dengan durasi rekaman voice over agar sinkron.

export const FPS = 30;

export interface Beat {
  text: string;
  seconds: number;
}

export interface Scene {
  emoji: string;
  title: string;
  beats: Beat[];
}

export const scenes: Scene[] = [
  {
    emoji: "☕",
    title: "KOK BISA BEDA?",
    beats: [
      { text: "Minum kopi yang sama, reaksinya beda banget 🤝", seconds: 3 },
      { text: "Kamu melek subuh 🌙 dia malah nguap 😴", seconds: 3 },
      { text: "Kok bisa? Yuk bongkar! 🔍", seconds: 2 },
    ],
  },
  {
    emoji: "🤯",
    title: "EFEKNYA UNIK",
    beats: [
      { text: "Bukan soal kopinya ☕", seconds: 2.5 },
      { text: "Jawabannya ada di tubuhmu 🧬", seconds: 2.5 },
      { text: "Gen, reseptor, kebiasaan 🎮", seconds: 2 },
    ],
  },
  {
    emoji: "😴",
    title: "Adenosin",
    beats: [
      { text: "Adenosin = zat pemicu ngantuk 💤", seconds: 3.5 },
      { text: "Kafein nyumpel reseptornya 🚫 ngantuk tertahan ⚡", seconds: 4 },
      { text: "Gen CYP1A2: kafein cepat habis atau awet? 🧪", seconds: 4 },
      { text: "Reseptor banyak? Adenosin menang 😵", seconds: 3.5 },
    ],
  },
  {
    emoji: "📈",
    title: "OTAK BISA ADAPTASI",
    beats: [
      { text: "Ngopi rutin = otak adaptasi 🧠 dosis makin gede", seconds: 4 },
      { text: "Pemula deg-degan 💓 pecandu 3 shot kayak teh ☕", seconds: 4 },
    ],
  },
  {
    emoji: "💥",
    title: "Crash adenosin",
    beats: [
      { text: "Kafein habis → adenosin nyerbu 🌊", seconds: 3 },
      { text: "Lemas, ngantuk parah, mati lampu 🪫", seconds: 3 },
      { text: "Kurang tidur? Makin parah 🥵", seconds: 2 },
    ],
  },
  {
    emoji: "🧠",
    title: "KENALI TUBUHMU",
    beats: [
      { text: "Otak mikir: ini waktunya istirahat 🛌", seconds: 3.5 },
      { text: "Kamu tim mana? Melek atau ngantuk? 🤔🔥", seconds: 3.5 },
    ],
  },
  {
    emoji: "🫵",
    title: "Giliran kamu!",
    beats: [
      { text: "Catat reaksimu tiap ngopi ☕📝", seconds: 3 },
      { text: "Follow KOPAKOPI buat belajar kopi! 🔔", seconds: 4 },
    ],
  },
];

export const sceneFrames = (s: Scene): number =>
  Math.round(s.beats.reduce((acc, b) => acc + b.seconds, 0) * FPS);

export const totalFrames = (): number =>
  scenes.reduce((acc, s) => acc + sceneFrames(s), 0);
