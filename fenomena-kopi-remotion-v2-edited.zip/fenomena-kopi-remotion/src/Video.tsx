import React from "react";
import {
  AbsoluteFill, Audio, Easing, Sequence, interpolate, spring,
  staticFile, useCurrentFrame, useVideoConfig,
} from "remotion";
import { loadFont as loadBebas } from "@remotion/google-fonts/BebasNeue";
import { loadFont as loadPoppins } from "@remotion/google-fonts/Poppins";
import { FPS, Scene, scenes, sceneFrames } from "./scenes";

const { fontFamily: TITLE_FONT } = loadBebas();
const { fontFamily: BODY_FONT } = loadPoppins("normal", { weights: ["600", "700", "800"], subsets: ["latin"] });
const NAVY = "#07152F";
const BLUE = "#123B78";
const ORANGE = "#FFB02E";
const CREAM = "#FFF8E9";

const Background: React.FC = () => {
  const f = useCurrentFrame();
  const drift = (f * 0.35) % 120;
  return <AbsoluteFill style={{ background: `radial-gradient(ellipse at 75% 20%, #17477D 0%, ${BLUE} 24%, ${NAVY} 76%)`, overflow: "hidden" }}>
    <AbsoluteFill style={{ opacity: .22, backgroundImage: "linear-gradient(rgba(255,255,255,.12) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.12) 1px,transparent 1px)", backgroundSize: "72px 72px", transform: `translateY(${drift}px)` }} />
    <div style={{ position:"absolute", width:760, height:760, border:"2px solid rgba(255,176,46,.14)", borderRadius:"50%", right:-390, top:260, transform:`rotate(${f*.12}deg)` }} />
    <div style={{ position:"absolute", width:520, height:520, border:"1px solid rgba(255,255,255,.10)", borderRadius:"50%", left:-300, bottom:180 }} />
    {[0,1,2,3,4,5,6,7,8,9].map(i => {
      const y = ((i*191 - f*(.7+i*.08)) % 2050 + 2050) % 2050;
      return <div key={i} style={{ position:"absolute", left:`${8+(i*17)%84}%`, top:y, width: i%3===0?7:4, height:i%3===0?7:4, borderRadius:20, background:i%2?ORANGE:CREAM, opacity:.5 }} />;
    })}
  </AbsoluteFill>;
};

const TopBar: React.FC<{index:number}> = ({index}) => {
  let start=0;
  return <div style={{position:"absolute",top:76,left:64,right:64,zIndex:5}}>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
      <div style={{fontFamily:BODY_FONT,fontSize:25,fontWeight:800,letterSpacing:4,color:CREAM}}>KOPAKOPI <span style={{color:ORANGE}}>LAB</span></div>
      <div style={{fontFamily:BODY_FONT,fontSize:20,fontWeight:700,color:"rgba(255,255,255,.65)"}}>EDUKASI KOPI • {String(index+1).padStart(2,"0")}/{String(scenes.length).padStart(2,"0")}</div>
    </div>
    <div style={{display:"flex",gap:8}}>
      {scenes.map((s,i)=>{const len=sceneFrames(s); const active=i===index; start+=len; return <div key={i} style={{height:7,flex:1,borderRadius:10,background:active?ORANGE:"rgba(255,255,255,.20)"}}/>;})}
    </div>
  </div>;
};

const Beat: React.FC<{text:string; accent?:boolean}> = ({text,accent=false}) => {
  const frame=useCurrentFrame(); const {fps,durationInFrames}=useVideoConfig();
  const p=spring({frame,fps,config:{damping:14,stiffness:125}});
  const out=interpolate(frame,[durationInFrames-7,durationInFrames],[1,0],{extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.in(Easing.quad)});
  const words=text.split(" ");
  return <AbsoluteFill style={{justifyContent:"center",alignItems:"center",padding:"0 78px 220px"}}>
    <div style={{maxWidth:930,background:accent?ORANGE:CREAM,color:NAVY,borderRadius:42,padding:"48px 50px",boxShadow:"0 16px 0 rgba(0,0,0,.18),0 34px 90px rgba(0,0,0,.28)",fontFamily:BODY_FONT,fontSize:61,fontWeight:800,lineHeight:1.22,textAlign:"center",opacity:p*out,transform:`translateY(${(1-p)*55}px) scale(${.94+.06*p})`}}>
      {words.map((w,i)=>{const q=spring({frame:frame-2-i*1.4,fps,config:{damping:13,stiffness:170}});return <span key={i} style={{display:"inline-block",opacity:q,transform:`translateY(${(1-q)*17}px)`,marginRight:14}}>{w}</span>;})}
    </div>
  </AbsoluteFill>;
};

const SceneView: React.FC<{scene:Scene;index:number}> = ({scene,index}) => {
  const frame=useCurrentFrame(); const {fps}=useVideoConfig();
  const title=spring({frame,fps,config:{damping:13,stiffness:95}});
  const emoji=spring({frame:frame-5,fps,config:{damping:7,stiffness:150}});
  let from=0;
  return <AbsoluteFill>
    <TopBar index={index}/>
    <div style={{position:"absolute",top:245,left:72,right:72,opacity:title,transform:`translateX(${(1-title)*-65}px)`}}>
      <div style={{fontFamily:TITLE_FONT,fontSize:128,lineHeight:.94,color:CREAM,letterSpacing:1}}>
        <span style={{display:"inline-block",transform:`scale(${emoji})`,marginRight:18}}>{scene.emoji}</span>
        <span style={{color:ORANGE}}>{scene.title}</span>
      </div>
      <div style={{width:150,height:9,background:ORANGE,borderRadius:10,marginTop:28,transform:`scaleX(${title})`,transformOrigin:"left"}}/>
    </div>
    {scene.beats.map((b,i)=>{const start=from;const len=Math.round(b.seconds*FPS);from+=len;return <Sequence key={i} from={start} durationInFrames={len}><Beat text={b.text} accent={i===scene.beats.length-1}/></Sequence>;})}
    <div style={{position:"absolute",bottom:82,left:72,right:72,display:"flex",justifyContent:"space-between",fontFamily:BODY_FONT,fontSize:20,fontWeight:700,color:"rgba(255,255,255,.55)"}}>
      <span>NGOPI • PAHAM • NIKMATI</span><span>SWIPE? FOLLOW! ↗</span>
    </div>
  </AbsoluteFill>;
};

export const FenomenaKopi: React.FC<{voUrl:string|null}> = ({voUrl}) => {
  let from=0;
  return <AbsoluteFill><Background/>
    {scenes.map((s,i)=>{const start=from;const len=sceneFrames(s);from+=len;return <Sequence key={i} from={start} durationInFrames={len}><SceneView scene={s} index={i}/></Sequence>;})}
    {voUrl && <Audio src={staticFile(voUrl)}/>}
  </AbsoluteFill>;
};
