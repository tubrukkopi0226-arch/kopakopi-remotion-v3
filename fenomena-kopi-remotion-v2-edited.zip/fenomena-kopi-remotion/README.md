# Fenomena Aneh Kopi: Remotion (vertikal 9:16)

Video vertikal untuk Reels, TikTok, dan Shorts, dengan gaya visual anak muda.

## Cara menjalankan
1. `npm install`
2. `npm start` untuk membuka Remotion Studio dan melihat preview.
3. `npm run render` untuk merender video tanpa voice over.

## Menambahkan voice over
1. Letakkan file audio VO (mis. `vo.mp3`) di folder `public/`.
2. Render dengan: `npx remotion render FenomenaKopi out/fenomena-kopi-vo.mp4 --props='{"voUrl":"vo.mp3"}'`

## Menyesuaikan sinkron
Durasi setiap teks diatur di `src/scenes.ts` lewat properti `seconds`.
Setelah VO direkam, samakan nilai `seconds` dengan durasi tiap kalimat.

## Update visual (v2)
- Font Bebas Neue (judul) + Poppins (teks), sama kayak slide. Jalankan `npm install` lagi (ada `@remotion/google-fonts`).
- Teks muncul kata per kata + zoom pelan biar mata nggak bosen.
- Transisi wipe oranye antar scene.
- Progress bar pindah ke atas (per scene), area bawah dikosongin buat UI TikTok/Reels.

## Durasi (v2.1)
Total dipangkas jadi ±60 detik (sebelumnya ±126 detik). Teks tiap beat dipersingkat, 2–4 detik per beat.


## Update visual v3
- Background navy-blue dengan grid halus dan partikel minimal.
- Branding KOPAKOPI LAB, indikator progres per scene, serta footer konsisten.
- Kartu teks krem/oranye dengan animasi kata-per-kata dan hierarchy judul lebih kuat.
- Area bawah tetap aman untuk UI TikTok/Reels.
